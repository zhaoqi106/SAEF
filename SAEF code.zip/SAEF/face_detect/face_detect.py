import torch
import numpy as np
from face_detect.data import cfg_mnet, cfg_slim, cfg_rfb
import cv2
from face_detect.layers.functions.prior_box import PriorBox
from face_detect.models.retinaface import RetinaFace
from face_detect.models.net_slim import Slim
from face_detect.models.net_rfb import RFB
from face_detect.utils.box_utils import decode, decode_landm
from face_detect.utils.nms.py_cpu_nms import py_cpu_nms
torch.set_grad_enabled(False)

def check_keys(model, pretrained_state_dict):
    ckpt_keys = set(pretrained_state_dict.keys())
    model_keys = set(model.state_dict().keys())
    used_pretrained_keys = model_keys & ckpt_keys
    unused_pretrained_keys = ckpt_keys - model_keys
    missing_keys = model_keys - ckpt_keys
    # print('Missing keys:{}'.format(len(missing_keys)))
    # print('Unused checkpoint keys:{}'.format(len(unused_pretrained_keys)))
    # print('Used keys:{}'.format(len(used_pretrained_keys)))r
    assert len(used_pretrained_keys) > 0, 'load NONE from pretrained checkpoint'
    return True

def remove_prefix(state_dict, prefix):
    ''' Old style model is stored with all names of parameters sharing common prefix 'module.' '''
    print('remove prefix \'{}\''.format(prefix))
    f = lambda x: x.split(prefix, 1)[-1] if x.startswith(prefix) else x
    return {f(key): value for key, value in state_dict.items()}

def load_model(model, pretrained_path, load_to_cpu):
    if load_to_cpu:
        pretrained_dict = torch.load(pretrained_path, map_location=lambda storage, loc: storage)
    else:
        device = torch.cuda.current_device()
        pretrained_dict = torch.load(pretrained_path, map_location=lambda storage, loc: storage.cuda(device))
    if "state_dict" in pretrained_dict.keys():
        pretrained_dict = remove_prefix(pretrained_dict['state_dict'], 'module.')
    else:
        pretrained_dict = remove_prefix(pretrained_dict, 'module.')
    check_keys(model, pretrained_dict)
    model.load_state_dict(pretrained_dict, strict=False)
    return model

class FaceDetect:
    def __init__(self, net_type="RFB", input_size=640, test_device="cuda:0"):
        self.m_net_type = net_type
        self.m_input_size = input_size
        self.m_test_device = test_device
        self.m_confidence_threshold = 0.02
        self.m_top_k = 5000
        self.m_nms_threshold = 0.4
        self.m_keep_top_k = 750
        self.m_vis_thres = 0.6
        if 0 != self.buildModel():
            raise ValueError('模型构建失败')
    

    def buildModel(self):
        if self.m_net_type == "mobile0.25":
            self.m_cfg = cfg_mnet
            self.m_net = RetinaFace(cfg = self.m_cfg, phase = 'test')
            weight = 'face_detect/weights/mobilenet0.25_Final.pth'
        elif self.m_net_type == "slim":
            self.m_cfg = cfg_slim
            self.m_net = Slim(cfg = self.m_cfg, phase = 'test')
            weight = 'face_detect/weights/slim_Final.pth'
        elif self.m_net_type == "RFB":
            self.m_cfg = cfg_rfb
            self.m_net = RFB(cfg = self.m_cfg, phase = 'test')
            weight = 'face_detect/weights/RBF_Final.pth'
        else:
            print("Don't support network!")
            return -1
        self.m_net = load_model(self.m_net, weight, self.m_test_device=='cpu')
        self.m_net.eval()

        self.m_net = self.m_net.to(self.m_test_device)
        return 0
    
    def getFaceLoc(self, orig_image):
        img = np.float32(orig_image)
        # testing scale
        target_size = self.m_input_size
        max_size = self.m_input_size
        im_shape = img.shape
        im_size_min = np.min(im_shape[0:2])
        im_size_max = np.max(im_shape[0:2])
        resize = float(target_size) / float(im_size_min)
        # prevent bigger axis from being more than max_size:
        if np.round(resize * im_size_max) > max_size:
            resize = float(max_size) / float(im_size_max)
        # if args.origin_size:
        #     resize = 1

        if resize != 1:
            img = cv2.resize(img, None, None, fx=resize, fy=resize, interpolation=cv2.INTER_LINEAR)
        im_height, im_width, _ = img.shape

        scale = torch.Tensor([img.shape[1], img.shape[0], img.shape[1], img.shape[0]])
        img -= (104, 117, 123)
        img = img.transpose(2, 0, 1)
        img = torch.from_numpy(img).unsqueeze(0)
        img = img.to(self.m_test_device)
        scale = scale.to(self.m_test_device)

        loc, conf, landms = self.m_net(img)  # forward pass

        priorbox = PriorBox(self.m_cfg, image_size=(im_height, im_width))
        priors = priorbox.forward()
        priors = priors.to(self.m_test_device)
        prior_data = priors.data
        boxes = decode(loc.data.squeeze(0), prior_data, self.m_cfg['variance'])
        boxes = boxes * scale / resize
        boxes = boxes.cpu().numpy()
        scores = conf.squeeze(0).data.cpu().numpy()[:, 1]
        landms = decode_landm(landms.data.squeeze(0), prior_data, self.m_cfg['variance'])
        scale1 = torch.Tensor([img.shape[3], img.shape[2], img.shape[3], img.shape[2],
                               img.shape[3], img.shape[2], img.shape[3], img.shape[2],
                               img.shape[3], img.shape[2]])
        scale1 = scale1.to(self.m_test_device)
        landms = landms * scale1 / resize
        landms = landms.cpu().numpy()

        # ignore low scores
        inds = np.where(scores > self.m_confidence_threshold)[0]
        boxes = boxes[inds]
        landms = landms[inds]
        scores = scores[inds]

        # keep top-K before NMS
        order = scores.argsort()[::-1][:self.m_top_k]
        boxes = boxes[order]
        landms = landms[order]
        scores = scores[order]

        # do NMS
        dets = np.hstack((boxes, scores[:, np.newaxis])).astype(np.float32, copy=False)
        keep = py_cpu_nms(dets, self.m_nms_threshold)
        # keep = nms(dets, args.nms_threshold,force_cpu=args.cpu)
        dets = dets[keep, :]
        landms = landms[keep]

        # keep top-K faster NMS
        dets = dets[:self.m_keep_top_k, :]
        landms = landms[:self.m_keep_top_k, :]

        boxes = []
        kpes = []
        dets = np.concatenate((dets, landms), axis=1)
        for b in dets:
            if b[4] < self.m_vis_thres:
                continue
            b = list(map(int, b))
            boxes.append(b[:4])
            kpes.append(b[5:15])
        return boxes, kpes
