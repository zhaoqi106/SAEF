# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'PostUI.ui'
##
## Created by: Qt User Interface Compiler version 6.6.3
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QGridLayout,
    QGroupBox, QHBoxLayout, QLabel, QLineEdit,
    QProgressBar, QPushButton, QSizePolicy, QSpacerItem,
    QTextBrowser, QVBoxLayout, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(731, 666)
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.groupBox = QGroupBox(Form)
        self.groupBox.setObjectName(u"groupBox")
        self.gridLayout = QGridLayout(self.groupBox)
        self.gridLayout.setObjectName(u"gridLayout")
        self.cb_eye = QCheckBox(self.groupBox)
        self.cb_eye.setObjectName(u"cb_eye")

        self.gridLayout.addWidget(self.cb_eye, 0, 0, 1, 1)

        self.cb_mouth = QCheckBox(self.groupBox)
        self.cb_mouth.setObjectName(u"cb_mouth")

        self.gridLayout.addWidget(self.cb_mouth, 0, 1, 1, 1)


        self.horizontalLayout_4.addWidget(self.groupBox)

        self.groupBox_2 = QGroupBox(Form)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.gridLayout_2 = QGridLayout(self.groupBox_2)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.label = QLabel(self.groupBox_2)
        self.label.setObjectName(u"label")

        self.gridLayout_2.addWidget(self.label, 0, 0, 1, 1)

        self.cb_encryption = QComboBox(self.groupBox_2)
        self.cb_encryption.addItem("")
        self.cb_encryption.addItem("")
        self.cb_encryption.addItem("")
        self.cb_encryption.addItem("")
        self.cb_encryption.setObjectName(u"cb_encryption")

        self.gridLayout_2.addWidget(self.cb_encryption, 0, 1, 1, 1)

        self.horizontalSpacer = QSpacerItem(72, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_2.addItem(self.horizontalSpacer, 0, 2, 1, 1)

        self.label_2 = QLabel(self.groupBox_2)
        self.label_2.setObjectName(u"label_2")

        self.gridLayout_2.addWidget(self.label_2, 1, 0, 1, 1)

        self.le_keyfile = QLineEdit(self.groupBox_2)
        self.le_keyfile.setObjectName(u"le_keyfile")

        self.gridLayout_2.addWidget(self.le_keyfile, 1, 1, 1, 1)

        self.btn_open_keyfile = QPushButton(self.groupBox_2)
        self.btn_open_keyfile.setObjectName(u"btn_open_keyfile")

        self.gridLayout_2.addWidget(self.btn_open_keyfile, 1, 2, 1, 1)

        self.gridLayout_2.setColumnStretch(0, 1)
        self.gridLayout_2.setColumnStretch(1, 4)
        self.gridLayout_2.setColumnStretch(2, 1)

        self.horizontalLayout_4.addWidget(self.groupBox_2)

        self.horizontalLayout_4.setStretch(0, 1)
        self.horizontalLayout_4.setStretch(1, 2)

        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.groupBox_3 = QGroupBox(Form)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.gridLayout_3 = QGridLayout(self.groupBox_3)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.label_3 = QLabel(self.groupBox_3)
        self.label_3.setObjectName(u"label_3")

        self.gridLayout_3.addWidget(self.label_3, 0, 0, 1, 1)

        self.le_file_path = QLineEdit(self.groupBox_3)
        self.le_file_path.setObjectName(u"le_file_path")

        self.gridLayout_3.addWidget(self.le_file_path, 0, 1, 1, 1)

        self.btn_open_file_path = QPushButton(self.groupBox_3)
        self.btn_open_file_path.setObjectName(u"btn_open_file_path")

        self.gridLayout_3.addWidget(self.btn_open_file_path, 0, 2, 1, 1)

        self.label_4 = QLabel(self.groupBox_3)
        self.label_4.setObjectName(u"label_4")

        self.gridLayout_3.addWidget(self.label_4, 1, 0, 1, 1)

        self.le_save_path = QLineEdit(self.groupBox_3)
        self.le_save_path.setObjectName(u"le_save_path")

        self.gridLayout_3.addWidget(self.le_save_path, 1, 1, 1, 1)

        self.btn_open_save_path = QPushButton(self.groupBox_3)
        self.btn_open_save_path.setObjectName(u"btn_open_save_path")

        self.gridLayout_3.addWidget(self.btn_open_save_path, 1, 2, 1, 1)


        self.verticalLayout.addWidget(self.groupBox_3)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.progressBar = QProgressBar(Form)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setValue(24)

        self.horizontalLayout_3.addWidget(self.progressBar)

        self.btn_start = QPushButton(Form)
        self.btn_start.setObjectName(u"btn_start")

        self.horizontalLayout_3.addWidget(self.btn_start)

        self.btn_stop = QPushButton(Form)
        self.btn_stop.setObjectName(u"btn_stop")

        self.horizontalLayout_3.addWidget(self.btn_stop)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.groupBox_5 = QGroupBox(Form)
        self.groupBox_5.setObjectName(u"groupBox_5")
        self.horizontalLayout_2 = QHBoxLayout(self.groupBox_5)
        self.horizontalLayout_2.setSpacing(6)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_image_1 = QLabel(self.groupBox_5)
        self.label_image_1.setObjectName(u"label_image_1")
        self.label_image_1.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_2.addWidget(self.label_image_1)

        self.label_5 = QLabel(self.groupBox_5)
        self.label_5.setObjectName(u"label_5")
        font = QFont()
        font.setPointSize(9)
        font.setBold(True)
        self.label_5.setFont(font)
        self.label_5.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_2.addWidget(self.label_5)

        self.label_image_2 = QLabel(self.groupBox_5)
        self.label_image_2.setObjectName(u"label_image_2")
        self.label_image_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_2.addWidget(self.label_image_2)

        self.horizontalLayout_2.setStretch(0, 10)
        self.horizontalLayout_2.setStretch(1, 1)
        self.horizontalLayout_2.setStretch(2, 10)

        self.verticalLayout.addWidget(self.groupBox_5)

        self.groupBox_4 = QGroupBox(Form)
        self.groupBox_4.setObjectName(u"groupBox_4")
        self.horizontalLayout = QHBoxLayout(self.groupBox_4)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.textBrowser = QTextBrowser(self.groupBox_4)
        self.textBrowser.setObjectName(u"textBrowser")

        self.horizontalLayout.addWidget(self.textBrowser)


        self.verticalLayout.addWidget(self.groupBox_4)

        self.verticalLayout.setStretch(0, 3)
        self.verticalLayout.setStretch(1, 3)
        self.verticalLayout.setStretch(2, 1)
        self.verticalLayout.setStretch(3, 10)
        self.verticalLayout.setStretch(4, 1)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.groupBox.setTitle(QCoreApplication.translate("Form", u"Privacy", None))
        self.cb_eye.setText(QCoreApplication.translate("Form", u"EYE", None))
        self.cb_mouth.setText(QCoreApplication.translate("Form", u"Mouth", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("Form", u"Encryption", None))
        self.label.setText(QCoreApplication.translate("Form", u"Encryption:", None))
        self.cb_encryption.setItemText(0, QCoreApplication.translate("Form", u"AES", None))
        self.cb_encryption.setItemText(1, QCoreApplication.translate("Form", u"Tea", None))
        self.cb_encryption.setItemText(2, QCoreApplication.translate("Form", u"DES", None))
        self.cb_encryption.setItemText(3, QCoreApplication.translate("Form", u"RSA", None))

        self.label_2.setText(QCoreApplication.translate("Form", u"Key File:", None))
        self.btn_open_keyfile.setText(QCoreApplication.translate("Form", u"open", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("Form", u"Path", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"filePath:", None))
        self.btn_open_file_path.setText(QCoreApplication.translate("Form", u"open", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"savePath:", None))
        self.btn_open_save_path.setText(QCoreApplication.translate("Form", u"open", None))
        self.btn_start.setText(QCoreApplication.translate("Form", u"start", None))
        self.btn_stop.setText(QCoreApplication.translate("Form", u"stop", None))
        self.groupBox_5.setTitle(QCoreApplication.translate("Form", u"Preview", None))
        self.label_image_1.setText(QCoreApplication.translate("Form", u"--", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"==\u300b", None))
        self.label_image_2.setText(QCoreApplication.translate("Form", u"--", None))
        self.groupBox_4.setTitle(QCoreApplication.translate("Form", u"Log", None))
    # retranslateUi

